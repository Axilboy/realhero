import { Dumbbell, Flame, Wallet, TrendingUp } from 'lucide-react';

export function MiniCards() {
  const protein = 118;
  const fat = 62;
  const carbs = 175;
  const caloriesCurrent = 1680;
  const caloriesGoal = 2100;
  const caloriesPercent = (caloriesCurrent / caloriesGoal) * 100;
  
  const total = protein + fat + carbs;
  const proteinPercent = (protein / total) * 100;
  const fatPercent = (fat / total) * 100;
  const carbsPercent = (carbs / total) * 100;
  
  return (
    <div className="px-4 mb-6">
      <div className="grid grid-cols-2 gap-3">
        {/* Body Card */}
        <div 
          className="rounded-xl p-4"
          style={{ 
            background: 'linear-gradient(135deg, rgba(184, 212, 201, 0.15) 0%, rgba(139, 176, 161, 0.1) 100%)',
            border: '1px solid rgba(184, 212, 201, 0.2)'
          }}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-1.5">
              <Dumbbell size={16} style={{ color: 'var(--rh-body)' }} />
              <span className="text-xs font-bold" style={{ color: 'var(--rh-text)' }}>
                ТЕЛО
              </span>
            </div>
            <Flame size={18} style={{ color: '#FF9966' }} />
          </div>
          
          <div className="mb-2">
            <div className="text-2xl font-bold mb-0.5" style={{ color: 'var(--rh-text)' }}>
              {caloriesCurrent}
            </div>
            <div className="text-xs" style={{ color: 'var(--rh-text-muted)' }}>
              / {caloriesGoal} ккал
            </div>
          </div>
          
          <div 
            className="h-1 rounded-full mb-2 overflow-hidden"
            style={{ backgroundColor: 'var(--rh-surface)' }}
          >
            <div 
              className="h-full rounded-full"
              style={{ 
                width: `${caloriesPercent}%`,
                backgroundColor: 'var(--rh-accent)'
              }}
            />
          </div>
          
          <div className="text-xs mb-2" style={{ color: 'var(--rh-text-secondary)' }}>
            Б {protein}г • Ж {fat}г • У {carbs}г
          </div>
          
          <div className="flex gap-0.5 h-1">
            <div 
              className="rounded-full" 
              style={{ 
                width: `${proteinPercent}%`,
                backgroundColor: '#81C995'
              }}
            />
            <div 
              className="rounded-full" 
              style={{ 
                width: `${fatPercent}%`,
                backgroundColor: '#F28B82'
              }}
            />
            <div 
              className="rounded-full" 
              style={{ 
                width: `${carbsPercent}%`,
                backgroundColor: '#8AB4FF'
              }}
            />
          </div>
        </div>
        
        {/* Finance Card */}
        <div 
          className="rounded-xl p-4"
          style={{ 
            background: 'linear-gradient(135deg, rgba(129, 201, 149, 0.15) 0%, rgba(103, 161, 119, 0.1) 100%)',
            border: '1px solid rgba(129, 201, 149, 0.2)'
          }}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-1.5">
              <Wallet size={16} style={{ color: '#FFD700' }} />
              <span className="text-xs font-bold" style={{ color: 'var(--rh-text)' }}>
                ФИНАНСЫ
              </span>
            </div>
            <TrendingUp size={18} style={{ color: 'var(--rh-positive)' }} />
          </div>
          
          <div className="mb-1">
            <div className="text-xs" style={{ color: 'var(--rh-text-muted)' }}>
              Всего
            </div>
            <div className="text-xl font-bold" style={{ color: 'var(--rh-text)' }}>
              1 204 500 ₽
            </div>
          </div>
          
          <div className="flex items-center gap-1 text-xs mt-3" style={{ color: 'var(--rh-text-secondary)' }}>
            <span>💰</span>
            <span>Пассив ~8 200 ₽/мес</span>
          </div>
        </div>
      </div>
    </div>
  );
}
