import { useState } from 'react';
import { Settings, Bell, LogOut } from 'lucide-react';
import { useLocation } from 'react-router';

export function TopBar() {
  const [language, setLanguage] = useState<'RU' | 'EN'>('RU');
  const location = useLocation();
  
  const isHeroPage = location.pathname === '/';
  
  const toggleLanguage = () => {
    setLanguage(prev => prev === 'RU' ? 'EN' : 'RU');
  };
  
  const getPageTitle = () => {
    if (location.pathname.includes('body')) return 'Тело';
    if (location.pathname.includes('development')) return 'Развитие';
    if (location.pathname.includes('finance')) return 'Финансы';
    if (location.pathname.includes('settings')) return 'Настройки';
    return 'Герой';
  };
  
  if (isHeroPage) {
    return (
      <div className="sticky top-0 z-10 px-4 py-3" style={{ 
        backgroundColor: 'var(--rh-bg)',
        borderBottom: '1px solid var(--rh-border-muted)'
      }}>
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-2xl font-bold" style={{ color: 'var(--rh-text)' }}>
            Герой
          </h1>
          <div className="flex gap-3">
            <button 
              className="transition-colors hover:opacity-80"
              style={{ color: 'var(--rh-text-muted)' }}
            >
              <Settings size={24} />
            </button>
            <button 
              className="transition-colors hover:opacity-80"
              style={{ color: 'var(--rh-text-muted)' }}
            >
              <Bell size={24} />
            </button>
          </div>
        </div>
        <div className="flex items-center gap-3 text-sm" style={{ color: 'var(--rh-text-secondary)' }}>
          <span>user@example.com</span>
          <button 
            onClick={toggleLanguage}
            className="hover:opacity-80 transition-opacity"
            style={{ color: 'var(--rh-accent)' }}
          >
            {language}
          </button>
          <button 
            className="flex items-center gap-1 hover:opacity-80 transition-opacity"
            style={{ color: 'var(--rh-text-muted)' }}
          >
            <LogOut size={14} />
            <span>Выйти</span>
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="sticky top-0 z-10 px-4 py-3" style={{ 
      backgroundColor: 'var(--rh-bg)',
      borderBottom: '1px solid var(--rh-border-muted)'
    }}>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold" style={{ color: 'var(--rh-text)' }}>
            {getPageTitle()}
          </h1>
          <div className="flex items-center gap-3 text-xs mt-1" style={{ color: 'var(--rh-text-secondary)' }}>
            <span>user@example.com</span>
          </div>
        </div>
        <div className="flex items-center gap-3 text-sm">
          <button 
            onClick={toggleLanguage}
            className="hover:opacity-80 transition-opacity"
            style={{ color: 'var(--rh-accent)' }}
          >
            {language}
          </button>
          <button 
            className="flex items-center gap-1 hover:opacity-80 transition-opacity"
            style={{ color: 'var(--rh-text-muted)' }}
          >
            <LogOut size={14} />
            <span className="text-xs">Выйти</span>
          </button>
        </div>
      </div>
    </div>
  );
}
