import { useState } from 'react';
import { Scale, TrendingDown, Calendar, Dumbbell, Activity } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const weightData = [
  { date: '20.03', weight: 82.5 },
  { date: '21.03', weight: 82.3 },
  { date: '22.03', weight: 82.1 },
  { date: '23.03', weight: 81.8 },
  { date: '24.03', weight: 81.9 },
  { date: '25.03', weight: 81.6 },
  { date: '26.03', weight: 81.4 },
];

export function BodyPage() {
  const [activeTab, setActiveTab] = useState<'main' | 'nutrition' | 'workout'>('main');
  
  const currentWeight = 81.4;
  const startWeight = 85.0;
  const weightChange = currentWeight - startWeight;
  
  const protein = 118;
  const fat = 62;
  const carbs = 175;
  const caloriesCurrent = 1680;
  const caloriesGoal = 2100;
  
  return (
    <div>
      {/* Tabs */}
      <div className="px-4 mb-4">
        <div 
          className="flex rounded-lg p-1"
          style={{ backgroundColor: 'var(--rh-surface)' }}
        >
          <button
            onClick={() => setActiveTab('main')}
            className="flex-1 py-2 px-3 rounded-md text-sm font-medium transition-all"
            style={{
              backgroundColor: activeTab === 'main' ? 'var(--rh-accent)' : 'transparent',
              color: activeTab === 'main' ? 'var(--rh-bg)' : 'var(--rh-text-secondary)'
            }}
          >
            Главная
          </button>
          <button
            onClick={() => setActiveTab('nutrition')}
            className="flex-1 py-2 px-3 rounded-md text-sm font-medium transition-all"
            style={{
              backgroundColor: activeTab === 'nutrition' ? 'var(--rh-accent)' : 'transparent',
              color: activeTab === 'nutrition' ? 'var(--rh-bg)' : 'var(--rh-text-secondary)'
            }}
          >
            Питание
          </button>
          <button
            onClick={() => setActiveTab('workout')}
            className="flex-1 py-2 px-3 rounded-md text-sm font-medium transition-all"
            style={{
              backgroundColor: activeTab === 'workout' ? 'var(--rh-accent)' : 'transparent',
              color: activeTab === 'workout' ? 'var(--rh-bg)' : 'var(--rh-text-secondary)'
            }}
          >
            Тренировки
          </button>
        </div>
      </div>
      
      {activeTab === 'main' && (
        <div className="px-4">
          {/* Weight Card */}
          <div 
            className="rounded-xl p-5 mb-4"
            style={{ 
              backgroundColor: 'var(--rh-surface)',
              border: '1px solid var(--rh-border)'
            }}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Scale size={24} style={{ color: 'var(--rh-accent)' }} />
                <h2 className="text-lg font-bold" style={{ color: 'var(--rh-text)' }}>
                  Вес
                </h2>
              </div>
              <button 
                className="text-xs px-3 py-1 rounded-lg transition-all hover:opacity-80"
                style={{ 
                  backgroundColor: 'var(--rh-surface-alt)',
                  color: 'var(--rh-accent)',
                  border: '1px solid var(--rh-border)'
                }}
              >
                Замер
              </button>
            </div>
            
            <div className="mb-2">
              <div className="text-4xl font-bold mb-1" style={{ color: 'var(--rh-text)' }}>
                {currentWeight} кг
              </div>
              <div className="flex items-center gap-2">
                <TrendingDown size={16} style={{ color: 'var(--rh-positive)' }} />
                <span className="text-sm" style={{ color: 'var(--rh-positive)' }}>
                  {Math.abs(weightChange).toFixed(1)} кг за период
                </span>
              </div>
            </div>
          </div>
          
          {/* Weight Chart */}
          <div 
            className="rounded-xl p-4 mb-4"
            style={{ 
              backgroundColor: 'var(--rh-surface)',
              border: '1px solid var(--rh-border)'
            }}
          >
            <h3 className="font-semibold mb-3" style={{ color: 'var(--rh-text)' }}>
              Динамика веса (7 дней)
            </h3>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={weightData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--rh-border)" />
                <XAxis 
                  dataKey="date" 
                  stroke="var(--rh-text-muted)" 
                  style={{ fontSize: '12px' }}
                />
                <YAxis 
                  stroke="var(--rh-text-muted)" 
                  style={{ fontSize: '12px' }}
                  domain={[80, 83]}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'var(--rh-surface-alt)',
                    border: '1px solid var(--rh-border)',
                    borderRadius: '8px',
                    color: 'var(--rh-text)'
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="weight" 
                  stroke="var(--rh-accent)" 
                  strokeWidth={3}
                  dot={{ fill: 'var(--rh-accent)', r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          
          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div 
              className="rounded-xl p-4"
              style={{ 
                backgroundColor: 'var(--rh-surface)',
                border: '1px solid var(--rh-border)'
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Activity size={18} style={{ color: 'var(--rh-body)' }} />
                <span className="text-xs font-semibold" style={{ color: 'var(--rh-text-muted)' }}>
                  Талия
                </span>
              </div>
              <div className="text-2xl font-bold" style={{ color: 'var(--rh-text)' }}>
                86 см
              </div>
            </div>
            
            <div 
              className="rounded-xl p-4"
              style={{ 
                backgroundColor: 'var(--rh-surface)',
                border: '1px solid var(--rh-border)'
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Dumbbell size={18} style={{ color: 'var(--rh-negative)' }} />
                <span className="text-xs font-semibold" style={{ color: 'var(--rh-text-muted)' }}>
                  Тренировки
                </span>
              </div>
              <div className="text-2xl font-bold" style={{ color: 'var(--rh-text)' }}>
                4 / 7 дней
              </div>
            </div>
          </div>
          
          {/* Today's Nutrition */}
          <div 
            className="rounded-xl p-5 mb-4"
            style={{ 
              backgroundColor: 'var(--rh-surface)',
              border: '1px solid var(--rh-border)'
            }}
          >
            <h3 className="font-semibold mb-3" style={{ color: 'var(--rh-text)' }}>
              БЖУ за сегодня
            </h3>
            
            <div className="mb-3">
              <div className="flex items-baseline justify-between mb-1">
                <span className="text-3xl font-bold" style={{ color: 'var(--rh-text)' }}>
                  {caloriesCurrent}
                </span>
                <span className="text-sm" style={{ color: 'var(--rh-text-muted)' }}>
                  / {caloriesGoal} ккал
                </span>
              </div>
              <div 
                className="h-2 rounded-full overflow-hidden"
                style={{ backgroundColor: 'var(--rh-surface-alt)' }}
              >
                <div 
                  className="h-full rounded-full"
                  style={{ 
                    width: `${(caloriesCurrent / caloriesGoal) * 100}%`,
                    backgroundColor: 'var(--rh-accent)'
                  }}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#81C995' }} />
                  <span style={{ color: 'var(--rh-text-secondary)' }}>Белки</span>
                </div>
                <span className="font-semibold" style={{ color: 'var(--rh-text)' }}>
                  {protein}г
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#F28B82' }} />
                  <span style={{ color: 'var(--rh-text-secondary)' }}>Жиры</span>
                </div>
                <span className="font-semibold" style={{ color: 'var(--rh-text)' }}>
                  {fat}г
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#8AB4FF' }} />
                  <span style={{ color: 'var(--rh-text-secondary)' }}>Углеводы</span>
                </div>
                <span className="font-semibold" style={{ color: 'var(--rh-text)' }}>
                  {carbs}г
                </span>
              </div>
            </div>
          </div>
          
          {/* Link to Measurements */}
          <button 
            className="w-full rounded-xl p-4 text-center transition-all hover:opacity-80"
            style={{ 
              backgroundColor: 'var(--rh-surface-alt)',
              color: 'var(--rh-text-secondary)',
              border: '1px solid var(--rh-border)'
            }}
          >
            <Calendar size={20} className="inline-block mr-2" />
            <span>Все замеры</span>
          </button>
        </div>
      )}
      
      {activeTab === 'nutrition' && (
        <div className="px-4">
          <div 
            className="rounded-xl p-6 text-center"
            style={{ 
              backgroundColor: 'var(--rh-surface)',
              border: '1px solid var(--rh-border)'
            }}
          >
            <div className="text-4xl mb-3">🍽️</div>
            <h3 className="font-semibold mb-2" style={{ color: 'var(--rh-text)' }}>
              Питание
            </h3>
            <p className="text-sm mb-4" style={{ color: 'var(--rh-text-secondary)' }}>
              Здесь будет детальный учёт приёмов пищи и калорий
            </p>
            <button 
              className="px-6 py-2 rounded-lg font-medium transition-all hover:opacity-90"
              style={{ 
                backgroundColor: 'var(--rh-accent)',
                color: 'var(--rh-bg)'
              }}
            >
              Добавить приём пищи
            </button>
          </div>
        </div>
      )}
      
      {activeTab === 'workout' && (
        <div className="px-4">
          <div 
            className="rounded-xl p-6 text-center"
            style={{ 
              backgroundColor: 'var(--rh-surface)',
              border: '1px solid var(--rh-border)'
            }}
          >
            <div className="text-4xl mb-3">💪</div>
            <h3 className="font-semibold mb-2" style={{ color: 'var(--rh-text)' }}>
              Тренировки
            </h3>
            <p className="text-sm mb-4" style={{ color: 'var(--rh-text-secondary)' }}>
              Программы тренировок и журнал подходов
            </p>
            <button 
              className="px-6 py-2 rounded-lg font-medium transition-all hover:opacity-90"
              style={{ 
                backgroundColor: 'var(--rh-accent)',
                color: 'var(--rh-bg)'
              }}
            >
              Начать тренировку
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
