import { useState } from 'react';
import { Wallet, TrendingUp, TrendingDown, PieChart, Plus, ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface Account {
  id: string;
  name: string;
  balance: number;
  type: 'cash' | 'card' | 'savings';
}

interface Transaction {
  id: string;
  title: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  date: string;
}

const mockAccounts: Account[] = [
  { id: '1', name: 'Основная карта', balance: 234500, type: 'card' },
  { id: '2', name: 'Сбережения', balance: 850000, type: 'savings' },
  { id: '3', name: 'Наличные', balance: 120000, type: 'cash' },
];

const mockTransactions: Transaction[] = [
  { id: '1', title: 'Зарплата', amount: 120000, type: 'income', category: 'Работа', date: '29 марта' },
  { id: '2', title: 'Продукты', amount: -4500, type: 'expense', category: 'Еда', date: '29 марта' },
  { id: '3', title: 'Бензин', amount: -3200, type: 'expense', category: 'Транспорт', date: '28 марта' },
  { id: '4', title: 'Фриланс', amount: 25000, type: 'income', category: 'Работа', date: '27 марта' },
];

export function FinancePage() {
  const [activeTab, setActiveTab] = useState<'main' | 'investments' | 'analytics' | 'budget'>('main');
  
  const totalBalance = mockAccounts.reduce((sum, acc) => sum + acc.balance, 0);
  const monthIncome = mockTransactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
  const monthExpense = Math.abs(mockTransactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0));
  const passiveIncome = 8200;
  
  return (
    <div>
      {/* Tabs */}
      <div className="px-4 mb-4">
        <div 
          className="flex rounded-lg p-1 overflow-x-auto"
          style={{ backgroundColor: 'var(--rh-surface)' }}
        >
          <button
            onClick={() => setActiveTab('main')}
            className="flex-shrink-0 py-2 px-4 rounded-md text-sm font-medium transition-all whitespace-nowrap"
            style={{
              backgroundColor: activeTab === 'main' ? 'var(--rh-accent)' : 'transparent',
              color: activeTab === 'main' ? 'var(--rh-bg)' : 'var(--rh-text-secondary)'
            }}
          >
            Главная
          </button>
          <button
            onClick={() => setActiveTab('investments')}
            className="flex-shrink-0 py-2 px-4 rounded-md text-sm font-medium transition-all whitespace-nowrap"
            style={{
              backgroundColor: activeTab === 'investments' ? 'var(--rh-accent)' : 'transparent',
              color: activeTab === 'investments' ? 'var(--rh-bg)' : 'var(--rh-text-secondary)'
            }}
          >
            Инвестиции
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className="flex-shrink-0 py-2 px-4 rounded-md text-sm font-medium transition-all whitespace-nowrap"
            style={{
              backgroundColor: activeTab === 'analytics' ? 'var(--rh-accent)' : 'transparent',
              color: activeTab === 'analytics' ? 'var(--rh-bg)' : 'var(--rh-text-secondary)'
            }}
          >
            Аналитика
          </button>
          <button
            onClick={() => setActiveTab('budget')}
            className="flex-shrink-0 py-2 px-4 rounded-md text-sm font-medium transition-all whitespace-nowrap"
            style={{
              backgroundColor: activeTab === 'budget' ? 'var(--rh-accent)' : 'transparent',
              color: activeTab === 'budget' ? 'var(--rh-bg)' : 'var(--rh-text-secondary)'
            }}
          >
            Бюджет
          </button>
        </div>
      </div>
      
      {activeTab === 'main' && (
        <div className="px-4">
          {/* Total Balance */}
          <div 
            className="rounded-xl p-5 mb-4"
            style={{ 
              background: 'linear-gradient(135deg, rgba(129, 201, 149, 0.15) 0%, rgba(103, 161, 119, 0.1) 100%)',
              border: '1px solid rgba(129, 201, 149, 0.2)'
            }}
          >
            <div className="flex items-center gap-2 mb-3">
              <Wallet size={24} style={{ color: '#FFD700' }} />
              <h2 className="text-lg font-bold" style={{ color: 'var(--rh-text)' }}>
                Всего
              </h2>
            </div>
            <div className="text-4xl font-bold mb-3" style={{ color: 'var(--rh-text)' }}>
              {totalBalance.toLocaleString('ru-RU')} ₽
            </div>
            <div className="flex items-center gap-2 text-sm">
              <TrendingUp size={16} style={{ color: 'var(--rh-positive)' }} />
              <span style={{ color: 'var(--rh-text-secondary)' }}>
                Пассив ~{passiveIncome.toLocaleString('ru-RU')} ₽/мес
              </span>
            </div>
          </div>
          
          {/* Accounts Carousel */}
          <div className="mb-4">
            <h3 className="text-sm font-semibold mb-3" style={{ color: 'var(--rh-text-muted)' }}>
              СЧЕТА
            </h3>
            <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4">
              {mockAccounts.map(account => (
                <div
                  key={account.id}
                  className="flex-shrink-0 w-64 rounded-xl p-4"
                  style={{ 
                    backgroundColor: 'var(--rh-surface)',
                    border: '1px solid var(--rh-border)'
                  }}
                >
                  <div className="text-xs mb-2" style={{ color: 'var(--rh-text-muted)' }}>
                    {account.name}
                  </div>
                  <div className="text-2xl font-bold" style={{ color: 'var(--rh-text)' }}>
                    {account.balance.toLocaleString('ru-RU')} ₽
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Monthly Summary */}
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div 
              className="rounded-xl p-4"
              style={{ 
                backgroundColor: 'var(--rh-surface)',
                border: '1px solid var(--rh-border)'
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <ArrowUpRight size={18} style={{ color: 'var(--rh-positive)' }} />
                <span className="text-xs" style={{ color: 'var(--rh-text-muted)' }}>
                  Доходы
                </span>
              </div>
              <div className="text-xl font-bold" style={{ color: 'var(--rh-positive)' }}>
                +{monthIncome.toLocaleString('ru-RU')} ₽
              </div>
            </div>
            
            <div 
              className="rounded-xl p-4"
              style={{ 
                backgroundColor: 'var(--rh-surface)',
                border: '1px solid var(--rh-border)'
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <ArrowDownRight size={18} style={{ color: 'var(--rh-negative)' }} />
                <span className="text-xs" style={{ color: 'var(--rh-text-muted)' }}>
                  Расходы
                </span>
              </div>
              <div className="text-xl font-bold" style={{ color: 'var(--rh-negative)' }}>
                -{monthExpense.toLocaleString('ru-RU')} ₽
              </div>
            </div>
          </div>
          
          {/* Recent Transactions */}
          <div className="mb-4">
            <h3 className="text-sm font-semibold mb-3" style={{ color: 'var(--rh-text-muted)' }}>
              ПОСЛЕДНИЕ ОПЕРАЦИИ
            </h3>
            <div className="space-y-2">
              {mockTransactions.map(transaction => (
                <div
                  key={transaction.id}
                  className="rounded-xl p-4 flex items-center justify-between"
                  style={{ 
                    backgroundColor: 'var(--rh-surface)',
                    border: '1px solid var(--rh-border)'
                  }}
                >
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-10 h-10 rounded-full flex items-center justify-center"
                      style={{ 
                        backgroundColor: transaction.type === 'income' 
                          ? 'rgba(129, 201, 149, 0.2)' 
                          : 'rgba(242, 139, 130, 0.2)'
                      }}
                    >
                      {transaction.type === 'income' ? (
                        <ArrowUpRight size={18} style={{ color: 'var(--rh-positive)' }} />
                      ) : (
                        <ArrowDownRight size={18} style={{ color: 'var(--rh-negative)' }} />
                      )}
                    </div>
                    <div>
                      <div className="font-medium" style={{ color: 'var(--rh-text)' }}>
                        {transaction.title}
                      </div>
                      <div className="text-xs" style={{ color: 'var(--rh-text-muted)' }}>
                        {transaction.category} • {transaction.date}
                      </div>
                    </div>
                  </div>
                  <div 
                    className="font-bold"
                    style={{ 
                      color: transaction.type === 'income' ? 'var(--rh-positive)' : 'var(--rh-negative)'
                    }}
                  >
                    {transaction.amount > 0 ? '+' : ''}{transaction.amount.toLocaleString('ru-RU')} ₽
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Add Transaction Button */}
          <button 
            className="w-full rounded-xl p-4 flex items-center justify-center gap-2 font-medium transition-all hover:opacity-90"
            style={{ 
              backgroundColor: 'var(--rh-accent)',
              color: 'var(--rh-bg)'
            }}
          >
            <Plus size={20} />
            <span>Добавить операцию</span>
          </button>
        </div>
      )}
      
      {activeTab === 'investments' && (
        <div className="px-4">
          <div 
            className="rounded-xl p-6 text-center"
            style={{ 
              backgroundColor: 'var(--rh-surface)',
              border: '1px solid var(--rh-border)'
            }}
          >
            <div className="text-4xl mb-3">📈</div>
            <h3 className="font-semibold mb-2" style={{ color: 'var(--rh-text)' }}>
              Инвестиции
            </h3>
            <p className="text-sm mb-4" style={{ color: 'var(--rh-text-secondary)' }}>
              Портфель, вклады и анализ доходности
            </p>
          </div>
        </div>
      )}
      
      {activeTab === 'analytics' && (
        <div className="px-4">
          <div 
            className="rounded-xl p-6 text-center"
            style={{ 
              backgroundColor: 'var(--rh-surface)',
              border: '1px solid var(--rh-border)'
            }}
          >
            <PieChart size={48} className="mx-auto mb-3" style={{ color: 'var(--rh-accent)' }} />
            <h3 className="font-semibold mb-2" style={{ color: 'var(--rh-text)' }}>
              Аналитика
            </h3>
            <p className="text-sm" style={{ color: 'var(--rh-text-secondary)' }}>
              Прогноз и разбивка по категориям
            </p>
          </div>
        </div>
      )}
      
      {activeTab === 'budget' && (
        <div className="px-4">
          <div 
            className="rounded-xl p-6 text-center"
            style={{ 
              backgroundColor: 'var(--rh-surface)',
              border: '1px solid var(--rh-border)'
            }}
          >
            <div className="text-4xl mb-3">💰</div>
            <h3 className="font-semibold mb-2" style={{ color: 'var(--rh-text)' }}>
              Бюджет
            </h3>
            <p className="text-sm" style={{ color: 'var(--rh-text-secondary)' }}>
              Планирование расходов по категориям
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
