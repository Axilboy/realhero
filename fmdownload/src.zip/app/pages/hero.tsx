import { UserProfile } from '../components/hero/user-profile';
import { TodaySection } from '../components/hero/today-section';
import { MiniCards } from '../components/hero/mini-cards';
import { QuestsSection } from '../components/hero/quests-section';

export function HeroPage() {
  return (
    <div className="pt-4">
      <UserProfile />
      <TodaySection />
      <MiniCards />
      <QuestsSection />
    </div>
  );
}
