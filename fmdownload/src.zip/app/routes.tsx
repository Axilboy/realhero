import { createBrowserRouter } from "react-router";
import { Layout } from "./components/layout";
import { HeroPage } from "./pages/hero";
import { BodyPage } from "./pages/body";
import { DevelopmentPage } from "./pages/development";
import { FinancePage } from "./pages/finance";
import { SettingsPage } from "./pages/settings";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: HeroPage },
      { path: "body", Component: BodyPage },
      { path: "development", Component: DevelopmentPage },
      { path: "finance", Component: FinancePage },
      { path: "settings", Component: SettingsPage },
    ],
  },
]);
