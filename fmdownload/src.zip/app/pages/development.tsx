import { useState } from 'react';
import { CheckCircle2, Circle, Calendar, Plus } from 'lucide-react';

interface Task {
  id: string;
  title: string;
  completed: boolean;
  dueDate?: string;
  category?: string;
}

const mockTasks: Task[] = [
  { id: '1', title: 'Тренировка в зале', completed: false, dueDate: 'Сегодня', category: 'Тело' },
  { id: '2', title: 'Обновить финансовый план', completed: false, dueDate: 'Сегодня', category: 'Финансы' },
  { id: '3', title: 'Медитация 10 минут', completed: true, dueDate: 'Сегодня', category: 'Развитие' },
  { id: '4', title: 'Прочитать 20 страниц книги', completed: false, dueDate: 'Завтра' },
  { id: '5', title: 'Сделать замеры тела', completed: false, dueDate: 'Завтра', category: 'Тело' },
];

export function DevelopmentPage() {
  const [activeTab, setActiveTab] = useState<'today' | 'inbox' | 'all'>('today');
  const [tasks, setTasks] = useState<Task[]>(mockTasks);
  
  const toggleTask = (id: string) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };
  
  const getFilteredTasks = () => {
    if (activeTab === 'today') {
      return tasks.filter(task => task.dueDate === 'Сегодня');
    }
    if (activeTab === 'inbox') {
      return tasks.filter(task => !task.category);
    }
    return tasks;
  };
  
  const filteredTasks = getFilteredTasks();
  const completedCount = filteredTasks.filter(t => t.completed).length;
  
  return (
    <div>
      {/* Tabs */}
      <div className="px-4 mb-4">
        <div 
          className="flex rounded-lg p-1"
          style={{ backgroundColor: 'var(--rh-surface)' }}
        >
          <button
            onClick={() => setActiveTab('today')}
            className="flex-1 py-2 px-3 rounded-md text-sm font-medium transition-all"
            style={{
              backgroundColor: activeTab === 'today' ? 'var(--rh-accent)' : 'transparent',
              color: activeTab === 'today' ? 'var(--rh-bg)' : 'var(--rh-text-secondary)'
            }}
          >
            Сегодня
          </button>
          <button
            onClick={() => setActiveTab('inbox')}
            className="flex-1 py-2 px-3 rounded-md text-sm font-medium transition-all"
            style={{
              backgroundColor: activeTab === 'inbox' ? 'var(--rh-accent)' : 'transparent',
              color: activeTab === 'inbox' ? 'var(--rh-bg)' : 'var(--rh-text-secondary)'
            }}
          >
            Входящие
          </button>
          <button
            onClick={() => setActiveTab('all')}
            className="flex-1 py-2 px-3 rounded-md text-sm font-medium transition-all"
            style={{
              backgroundColor: activeTab === 'all' ? 'var(--rh-accent)' : 'transparent',
              color: activeTab === 'all' ? 'var(--rh-bg)' : 'var(--rh-text-secondary)'
            }}
          >
            Все
          </button>
        </div>
      </div>
      
      <div className="px-4">
        {/* Progress */}
        <div 
          className="rounded-xl p-4 mb-4"
          style={{ 
            backgroundColor: 'var(--rh-surface)',
            border: '1px solid var(--rh-border)'
          }}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm" style={{ color: 'var(--rh-text-secondary)' }}>
              Выполнено
            </span>
            <span className="font-semibold" style={{ color: 'var(--rh-text)' }}>
              {completedCount} / {filteredTasks.length}
            </span>
          </div>
          <div 
            className="h-2 rounded-full overflow-hidden"
            style={{ backgroundColor: 'var(--rh-surface-alt)' }}
          >
            <div 
              className="h-full rounded-full transition-all"
              style={{ 
                width: `${filteredTasks.length > 0 ? (completedCount / filteredTasks.length) * 100 : 0}%`,
                backgroundColor: 'var(--rh-accent)'
              }}
            />
          </div>
        </div>
        
        {/* Tasks List */}
        <div className="space-y-2 mb-4">
          {filteredTasks.length === 0 ? (
            <div 
              className="rounded-xl p-8 text-center"
              style={{ 
                backgroundColor: 'var(--rh-surface)',
                border: '1px solid var(--rh-border)'
              }}
            >
              <div className="text-4xl mb-3">🎯</div>
              <h3 className="font-semibold mb-2" style={{ color: 'var(--rh-text)' }}>
                Нет задач
              </h3>
              <p className="text-sm" style={{ color: 'var(--rh-text-secondary)' }}>
                Все задачи выполнены или список пуст
              </p>
            </div>
          ) : (
            filteredTasks.map(task => (
              <div
                key={task.id}
                className="rounded-xl p-4 flex items-start gap-3 transition-all hover:opacity-90 cursor-pointer"
                style={{ 
                  backgroundColor: 'var(--rh-surface)',
                  border: '1px solid var(--rh-border)',
                  opacity: task.completed ? 0.6 : 1
                }}
                onClick={() => toggleTask(task.id)}
              >
                <button className="flex-shrink-0 mt-0.5">
                  {task.completed ? (
                    <CheckCircle2 size={22} style={{ color: 'var(--rh-positive)' }} />
                  ) : (
                    <Circle size={22} style={{ color: 'var(--rh-text-muted)' }} />
                  )}
                </button>
                
                <div className="flex-1">
                  <div 
                    className="font-medium mb-1"
                    style={{ 
                      color: 'var(--rh-text)',
                      textDecoration: task.completed ? 'line-through' : 'none'
                    }}
                  >
                    {task.title}
                  </div>
                  <div className="flex items-center gap-3 text-xs">
                    {task.dueDate && (
                      <div 
                        className="flex items-center gap-1"
                        style={{ color: 'var(--rh-text-muted)' }}
                      >
                        <Calendar size={12} />
                        <span>{task.dueDate}</span>
                      </div>
                    )}
                    {task.category && (
                      <span 
                        className="px-2 py-0.5 rounded-full text-xs"
                        style={{ 
                          backgroundColor: 'var(--rh-surface-alt)',
                          color: 'var(--rh-accent)'
                        }}
                      >
                        {task.category}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
        
        {/* Add Task Button */}
        <button 
          className="w-full rounded-xl p-4 flex items-center justify-center gap-2 font-medium transition-all hover:opacity-90"
          style={{ 
            backgroundColor: 'var(--rh-accent)',
            color: 'var(--rh-bg)'
          }}
        >
          <Plus size={20} />
          <span>Добавить задачу</span>
        </button>
      </div>
    </div>
  );
}
