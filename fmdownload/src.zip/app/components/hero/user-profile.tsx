import { Flame, Activity } from 'lucide-react';

export function UserProfile() {
  const currentExp = 375;
  const maxExp = 1200;
  const level = 14;
  const expPercent = (currentExp / maxExp) * 100;
  
  return (
    <div className="px-4 mb-6">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-14 h-14 rounded-full flex items-center justify-center text-2xl"
          style={{ 
            background: 'linear-gradient(135deg, var(--rh-accent) 0%, #6B8FD9 100%)'
          }}
        >
          🏋️
        </div>
        <div className="flex-1">
          <div className="text-xs mb-0.5" style={{ color: 'var(--rh-text-muted)' }}>
            Уровень {level} · Новичок
          </div>
          <div className="font-semibold mb-1.5" style={{ color: 'var(--rh-text)' }}>
            Артем С.
          </div>
          <div className="flex items-center gap-2">
            <div 
              className="flex-1 h-2 rounded-full overflow-hidden"
              style={{ backgroundColor: 'var(--rh-surface-alt)' }}
            >
              <div 
                className="h-full rounded-full transition-all duration-300" 
                style={{ 
                  width: `${expPercent}%`,
                  background: 'linear-gradient(90deg, var(--rh-accent) 0%, #6B8FD9 100%)'
                }}
              />
            </div>
            <div className="text-xs whitespace-nowrap" style={{ color: 'var(--rh-text-muted)' }}>
              {currentExp} / {maxExp}
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex gap-2">
        <div 
          className="flex items-center gap-1.5 rounded-full px-3 py-1.5"
          style={{ 
            backgroundColor: 'rgba(242, 139, 130, 0.1)',
            border: '1px solid rgba(242, 139, 130, 0.3)'
          }}
        >
          <Flame size={14} style={{ color: 'var(--rh-negative)' }} />
          <span className="text-xs font-medium" style={{ color: 'var(--rh-negative)' }}>
            Тренировки: 6 дней
          </span>
        </div>
        <div 
          className="flex items-center gap-1.5 rounded-full px-3 py-1.5"
          style={{ 
            backgroundColor: 'rgba(184, 212, 201, 0.1)',
            border: '1px solid rgba(184, 212, 201, 0.3)'
          }}
        >
          <Activity size={14} style={{ color: 'var(--rh-body)' }} />
          <span className="text-xs font-medium" style={{ color: 'var(--rh-body)' }}>
            Замеры: 4 дня
          </span>
        </div>
      </div>
    </div>
  );
}
