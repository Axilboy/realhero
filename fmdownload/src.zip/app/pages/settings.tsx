import { Globe, LogOut, Bell, Moon, Download, Info } from 'lucide-react';
import { useState } from 'react';

export function SettingsPage() {
  const [language, setLanguage] = useState<'RU' | 'EN'>('RU');
  
  const toggleLanguage = () => {
    setLanguage(prev => prev === 'RU' ? 'EN' : 'RU');
  };
  
  const settingsSections = [
    {
      title: 'ОСНОВНОЕ',
      items: [
        { 
          icon: Globe, 
          label: 'Язык', 
          value: language,
          action: toggleLanguage
        },
        { 
          icon: Bell, 
          label: 'Уведомления', 
          value: 'Скоро',
          disabled: true
        },
        { 
          icon: Moon, 
          label: 'Тема', 
          value: 'Тёмная',
          disabled: true
        },
      ]
    },
    {
      title: 'ДАННЫЕ',
      items: [
        { 
          icon: Download, 
          label: 'Экспорт данных', 
          value: 'Скоро',
          disabled: true
        },
      ]
    },
    {
      title: 'О ПРИЛОЖЕНИИ',
      items: [
        { 
          icon: Info, 
          label: 'Версия', 
          value: 'v2.0.0'
        },
      ]
    },
    {
      title: 'АККАУНТ',
      items: [
        { 
          icon: LogOut, 
          label: 'Выйти из аккаунта',
          isDestructive: true
        },
      ]
    }
  ];
  
  return (
    <div className="px-4">
      {/* User Profile Card */}
      <div 
        className="rounded-xl p-5 mb-6"
        style={{ 
          backgroundColor: 'var(--rh-surface)',
          border: '1px solid var(--rh-border)'
        }}
      >
        <div className="flex items-center gap-3">
          <div className="w-16 h-16 rounded-full flex items-center justify-center text-3xl"
            style={{ 
              background: 'linear-gradient(135deg, var(--rh-accent) 0%, #6B8FD9 100%)'
            }}
          >
            🏋️
          </div>
          <div className="flex-1">
            <div className="font-bold mb-1" style={{ color: 'var(--rh-text)' }}>
              Артем С.
            </div>
            <div className="text-sm" style={{ color: 'var(--rh-text-secondary)' }}>
              user@example.com
            </div>
            <div className="text-xs mt-1" style={{ color: 'var(--rh-text-muted)' }}>
              Уровень 14 • Новичок
            </div>
          </div>
        </div>
      </div>
      
      {/* Settings Sections */}
      {settingsSections.map((section, sectionIndex) => (
        <div key={sectionIndex} className="mb-6">
          <h3 
            className="text-xs font-bold mb-3 tracking-wider"
            style={{ color: 'var(--rh-text-muted)' }}
          >
            {section.title}
          </h3>
          
          <div 
            className="rounded-xl overflow-hidden"
            style={{ 
              backgroundColor: 'var(--rh-surface)',
              border: '1px solid var(--rh-border)'
            }}
          >
            {section.items.map((item, itemIndex) => {
              const Icon = item.icon;
              const isLast = itemIndex === section.items.length - 1;
              
              return (
                <button
                  key={itemIndex}
                  onClick={item.action}
                  disabled={item.disabled}
                  className="w-full p-4 flex items-center justify-between transition-all hover:opacity-80"
                  style={{ 
                    borderBottom: !isLast ? '1px solid var(--rh-border)' : 'none',
                    opacity: item.disabled ? 0.5 : 1,
                    cursor: item.disabled ? 'not-allowed' : 'pointer'
                  }}
                >
                  <div className="flex items-center gap-3">
                    <Icon 
                      size={20} 
                      style={{ 
                        color: item.isDestructive ? 'var(--rh-negative)' : 'var(--rh-text-muted)'
                      }} 
                    />
                    <span 
                      className="font-medium"
                      style={{ 
                        color: item.isDestructive ? 'var(--rh-negative)' : 'var(--rh-text)'
                      }}
                    >
                      {item.label}
                    </span>
                  </div>
                  {item.value && (
                    <span 
                      className="text-sm"
                      style={{ color: 'var(--rh-text-muted)' }}
                    >
                      {item.value}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      ))}
      
      {/* Footer Info */}
      <div 
        className="text-center text-xs py-4"
        style={{ color: 'var(--rh-text-muted)' }}
      >
        <p className="mb-1">Real Hero</p>
        <p>Геймификация жизни • Версия 2.0</p>
      </div>
    </div>
  );
}
