import { Home, Dumbbell, Rocket, Wallet, Settings } from 'lucide-react';
import { Link, useLocation } from 'react-router';

export function BottomNav() {
  const location = useLocation();
  
  const navItems = [
    { path: '/', icon: Home, label: 'Герой' },
    { path: '/body', icon: Dumbbell, label: 'Тело' },
    { path: '/development', icon: Rocket, label: 'Развитие' },
    { path: '/finance', icon: Wallet, label: 'Финансы' },
    { path: '/settings', icon: Settings, label: 'Настройки' },
  ];
  
  return (
    <div 
      className="fixed bottom-0 left-0 right-0 z-20"
      style={{ 
        backgroundColor: 'var(--rh-nav-bg)',
        borderTop: '1px solid var(--rh-nav-border)'
      }}
    >
      <div className="max-w-[428px] mx-auto flex items-center justify-around py-2 px-2">
        {navItems.map(({ path, icon: Icon, label }) => {
          const isActive = location.pathname === path;
          return (
            <Link
              key={path}
              to={path}
              className="flex flex-col items-center gap-1 py-1 px-2 min-w-[60px] transition-colors"
              style={{ 
                color: isActive ? 'var(--rh-accent)' : 'var(--rh-text-muted)'
              }}
            >
              <Icon size={22} strokeWidth={2} />
              <span className="text-[10px] font-medium">{label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
