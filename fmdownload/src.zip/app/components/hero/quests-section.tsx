import { Swords, Apple } from 'lucide-react';

export function QuestsSection() {
  return (
    <div className="px-4 mb-6">
      <h3 
        className="text-xs font-bold mb-3 tracking-wider"
        style={{ color: 'var(--rh-text-muted)' }}
      >
        КВЕСТЫ
      </h3>
      
      {/* Active Quest */}
      <div 
        className="rounded-xl p-4 mb-4"
        style={{ 
          backgroundColor: 'var(--rh-surface)',
          border: '1px solid var(--rh-border)'
        }}
      >
        <div className="flex items-start gap-3 mb-3">
          <div 
            className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
            style={{ backgroundColor: 'rgba(242, 139, 130, 0.2)' }}
          >
            <Swords size={20} style={{ color: 'var(--rh-negative)' }} />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <h4 className="font-semibold" style={{ color: 'var(--rh-text)' }}>
                Квест: Спартанец
              </h4>
              <span className="text-xs" style={{ color: 'var(--rh-text-muted)' }}>
                2/5
              </span>
            </div>
            <p className="text-sm" style={{ color: 'var(--rh-text-secondary)' }}>
              Посетить зал 5 раз за неделю
            </p>
          </div>
        </div>
        
        <div 
          className="h-1.5 rounded-full mb-3 overflow-hidden"
          style={{ backgroundColor: 'var(--rh-surface-alt)' }}
        >
          <div 
            className="h-full rounded-full"
            style={{ 
              width: '40%',
              backgroundColor: 'var(--rh-accent)'
            }}
          />
        </div>
        
        <div className="flex gap-2">
          <button 
            className="flex-1 rounded-lg px-4 py-2 text-sm font-medium transition-all hover:opacity-90"
            style={{ 
              backgroundColor: 'var(--rh-accent)',
              color: 'var(--rh-bg)'
            }}
          >
            К задачам
          </button>
          <button 
            className="flex-1 rounded-lg px-4 py-2 text-sm font-medium transition-all hover:opacity-90"
            style={{ 
              backgroundColor: 'var(--rh-surface-alt)',
              color: 'var(--rh-text)',
              border: '1px solid var(--rh-border)'
            }}
          >
            Отказаться
          </button>
        </div>
      </div>
      
      <h3 
        className="text-xs font-bold mb-3 tracking-wider"
        style={{ color: 'var(--rh-text-muted)' }}
      >
        ДОСТУПНЫЕ КВЕСТЫ
      </h3>
      
      {/* Available Quest */}
      <div 
        className="rounded-xl p-4"
        style={{ 
          backgroundColor: 'var(--rh-surface)',
          border: '1px solid var(--rh-border)'
        }}
      >
        <div className="flex items-start gap-3">
          <div 
            className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
            style={{ backgroundColor: 'rgba(129, 201, 149, 0.2)' }}
          >
            <Apple size={20} style={{ color: 'var(--rh-positive)' }} />
          </div>
          <div className="flex-1">
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1">
                <h4 className="font-semibold mb-1" style={{ color: 'var(--rh-text)' }}>
                  Чистое Питание
                </h4>
                <p className="text-sm" style={{ color: 'var(--rh-text-secondary)' }}>
                  Соблюдать диету 7 дней
                </p>
              </div>
              <button 
                className="rounded-lg px-3 py-1.5 text-xs font-medium whitespace-nowrap transition-all hover:opacity-90"
                style={{ 
                  backgroundColor: 'var(--rh-accent)',
                  color: 'var(--rh-bg)'
                }}
              >
                Начать
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
