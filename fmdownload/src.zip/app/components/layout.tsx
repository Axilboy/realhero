import { Outlet } from 'react-router';
import { TopBar } from './top-bar';
import { BottomNav } from './bottom-nav';

export function Layout() {
  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--rh-bg)' }}>
      <div className="max-w-[428px] mx-auto min-h-screen relative pb-20" style={{ backgroundColor: 'var(--rh-bg)' }}>
        <TopBar />
        <main className="pb-4">
          <Outlet />
        </main>
        <BottomNav />
      </div>
    </div>
  );
}
