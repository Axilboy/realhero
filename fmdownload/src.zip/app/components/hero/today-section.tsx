import { Link } from 'react-router';
import { Dumbbell, CheckSquare } from 'lucide-react';

export function TodaySection() {
  return (
    <div className="px-4 mb-6">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold" style={{ color: 'var(--rh-text)' }}>
          Сегодня
        </h3>
        <Link 
          to="/development"
          className="text-sm hover:opacity-80 transition-opacity"
          style={{ color: 'var(--rh-accent)' }}
        >
          К задачам
        </Link>
      </div>
      
      <div className="flex gap-2 mb-3">
        <Link
          to="/body"
          className="flex-1 rounded-xl px-4 py-3 flex items-center justify-center gap-2 transition-all hover:opacity-90"
          style={{ backgroundColor: 'var(--rh-accent)', color: 'var(--rh-bg)' }}
        >
          <Dumbbell size={18} strokeWidth={2.5} />
          <span className="font-semibold">ТЕЛО</span>
        </Link>
        <Link
          to="/development"
          className="flex-1 rounded-xl px-4 py-3 flex items-center justify-center gap-2 transition-all hover:opacity-90"
          style={{ 
            backgroundColor: 'var(--rh-surface-alt)',
            color: 'var(--rh-text)',
            border: '1px solid var(--rh-border)'
          }}
        >
          <CheckSquare size={18} strokeWidth={2.5} />
          <span className="font-semibold">ЗАДАЧИ</span>
        </Link>
      </div>
    </div>
  );
}
